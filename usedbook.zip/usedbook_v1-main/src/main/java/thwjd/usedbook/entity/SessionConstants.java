package thwjd.usedbook.entity;

public interface SessionConstants {
    String LOGIN_MEMBER = "loginMember";
    //먼저 HttpSession에서 로그인용으로 사용할 세션 id는 여기저기서 사용될 것이기 때문에 상수로 뺀다.
}
